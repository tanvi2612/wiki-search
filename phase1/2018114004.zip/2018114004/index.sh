rm -rf $2/index.txt
rm -rf $3
python indexing.py $1 $2 $3